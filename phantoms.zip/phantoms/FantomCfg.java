package phantoms;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class FantomCfg {
   private static final String FANTOMS_FILE = "./config/fantoms.properties";
   public static boolean ENABLE_FANTOMS;
   public static boolean FANTOM_SPAWN;
   public static long FANTOM_START_SPAWN_INTERVAL;
   public static int FANTOM_SPAWN_TYPE;
   public static int FANTOM_SPAWN_COUNT;
   public static long FANTOM_SPAWN_INTERVAL_MIN;
   public static long FANTOM_SPAWN_INTERVAL_MAX;
   public static long FANTOM_UNSPAWN_INTERVAL_MIN;
   public static long FANTOM_UNSPAWN_INTERVAL_MAX;
   public static long FANTOM_FIRST_AI_MIN;
   public static long FANTOM_FIRST_AI_MAX;
   public static long FANTOM_LIFE_CYCLE_MIN;
   public static long FANTOM_LIFE_CYCLE_MAX;
   public static int FANTOM_TITLE_CHANCE;
   public static long FANTOM_AI_MAX_TIME;
   public static int FANTOM_LOG_MIN_LVL;
   public static int FANTOM_LOG_MAX_LVL;
   public static List<String> RESTRICT_SPAWN_ZONES_NAME = new ArrayList();
   public static boolean FANTOM_ENABLE_CREATING_AI;
   public static List<Integer> FANTOM_RESTRICT_EQUIPMENT = new ArrayList();
   public static boolean FANTOM_UNSPAWN_NO_PEACE;
   public static boolean FANTOM_BUFFS;
   public static List<String> FANTOM_F_BUFFS = new ArrayList();
   public static List<String> FANTOM_M_BUFFS = new ArrayList();
   public static boolean ENABLE_CHAT_MOVE;
   public static int FANTOM_CHAT_MOVE_RATE;
   public static int FANTOM_CHAT_MOVE_RATE_SHOUT;
   public static int FANTOM_CHAT_MOVE_RATE_TRADE;
   public static boolean ENABLE_CHAT_MOVE_ONLYPEACE;
   public static boolean ENABLE_CHAT_KILL;
   public static int FANTOM_CHAT_KILL_RATE;
   public static int FANTOM_CHAT_KILL_RATE_SHOUT;
   public static int FANTOM_CHAT_KILL_RATE_TRADE;
   public static boolean ENABLE_CHAT_DIE;
   public static int FANTOM_CHAT_DIE_RATE;
   public static int FANTOM_CHAT_DIE_RATE_SHOUT;
   public static int FANTOM_CHAT_DIE_RATE_TRADE;
   private static boolean loaded = false;

   public static void load() {
      if (!loaded) {
         RESTRICT_SPAWN_ZONES_NAME.clear();
         FANTOM_RESTRICT_EQUIPMENT.clear();
         FANTOM_F_BUFFS.clear();
         FANTOM_M_BUFFS.clear();

         try {
            Properties cfg = new Properties();
            InputStream is = new FileInputStream(new File("./config/fantoms.properties"));
            cfg.load(is);
            is.close();
            String[] propertySplit = null;
            String splitCheck = "off";
            ENABLE_FANTOMS = Boolean.parseBoolean(cfg.getProperty("EnableFantoms", "false"));
            FANTOM_UNSPAWN_NO_PEACE = Boolean.parseBoolean(cfg.getProperty("FantomsUnspawnNoPeace", "false"));
            if (ENABLE_FANTOMS) {
               FANTOM_BUFFS = Boolean.parseBoolean(cfg.getProperty("FantomsBuffs", "false"));
               String[] split = cfg.getProperty("FantomsFighterBuffs", "1,2,3,4").split(";");
               String[] var8 = split;
               int var7 = split.length;

               for(int var6 = 0; var6 < var7; ++var6) {
                  String readData = var8[var6];
                  if (readData != null) {
                     FANTOM_F_BUFFS.add(readData);
                  }
               }

               String[] split2 = cfg.getProperty("FantomsMageBuffs", "1,2,3,4").split(";");
               String[] var9 = split2;
               int var13 = split2.length;

               String equip;
               for(var7 = 0; var7 < var13; ++var7) {
                  equip = var9[var7];
                  if (equip != null) {
                     FANTOM_M_BUFFS.add(equip);
                  }
               }

               FANTOM_SPAWN = Boolean.parseBoolean(cfg.getProperty("FantomsSpawn", "false"));
               FANTOM_ENABLE_CREATING_AI = Boolean.parseBoolean(cfg.getProperty("EnableCreatingAi", "true"));
               FANTOM_START_SPAWN_INTERVAL = TimeUnit.MINUTES.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsStartSpawnInterval", "1")));
               FANTOM_SPAWN_TYPE = Integer.parseInt(cfg.getProperty("FantomsSpawnType", "1"));
               FANTOM_SPAWN_COUNT = Integer.parseInt(cfg.getProperty("FantomsSpawnCount", "100"));
               FANTOM_SPAWN_INTERVAL_MIN = TimeUnit.SECONDS.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsSpawnIntervalMin", "1")));
               FANTOM_SPAWN_INTERVAL_MAX = TimeUnit.SECONDS.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsSpawnIntervalMax", "5")));
               FANTOM_LIFE_CYCLE_MIN = TimeUnit.MINUTES.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsLifeCycleMin", "1")));
               FANTOM_LIFE_CYCLE_MAX = TimeUnit.MINUTES.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsLifeCycleMax", "5")));
               FANTOM_UNSPAWN_INTERVAL_MIN = TimeUnit.SECONDS.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsUnspawnIntervalMin", "1")));
               FANTOM_UNSPAWN_INTERVAL_MAX = TimeUnit.SECONDS.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsUnspawnIntervalMax", "5")));
               FANTOM_FIRST_AI_MIN = TimeUnit.SECONDS.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsFirstAiStartMin", "1")));
               FANTOM_FIRST_AI_MAX = TimeUnit.SECONDS.toMillis((long)Integer.parseInt(cfg.getProperty("FantomsFirstAiStartMax", "5")));
               FANTOM_LOG_MIN_LVL = Integer.parseInt(cfg.getProperty("FantomsMinLvl", "1"));
               FANTOM_LOG_MAX_LVL = Integer.parseInt(cfg.getProperty("FantomsMaxLvl", "80"));
               FANTOM_TITLE_CHANCE = Integer.parseInt(cfg.getProperty("FantomsTitleChance", "60"));
               FANTOM_AI_MAX_TIME = TimeUnit.SECONDS.toMillis(Long.parseLong(cfg.getProperty("FantomsAiMaxTime", "15")));
               if (!cfg.getProperty("RestrictSpawnZonesName", "").isEmpty()) {
                  var13 = (var9 = cfg.getProperty("RestrictSpawnZonesName", "").split(",")).length;

                  for(var7 = 0; var7 < var13; ++var7) {
                     equip = var9[var7];
                     RESTRICT_SPAWN_ZONES_NAME.add(equip.trim());
                  }
               }

               if (!cfg.getProperty("RestrictEquipment", "").isEmpty()) {
                  var13 = (var9 = cfg.getProperty("RestrictEquipment", "").split(",")).length;

                  for(var7 = 0; var7 < var13; ++var7) {
                     equip = var9[var7];
                     FANTOM_RESTRICT_EQUIPMENT.add(Integer.valueOf(equip.trim()));
                  }
               }

               ENABLE_CHAT_MOVE = Boolean.parseBoolean(cfg.getProperty("EnableChatMove", "false"));
               FANTOM_CHAT_MOVE_RATE = Integer.parseInt(cfg.getProperty("ChatMoveRate", "50"));
               FANTOM_CHAT_MOVE_RATE_SHOUT = Integer.parseInt(cfg.getProperty("ChatMoveRateShout", "50"));
               FANTOM_CHAT_MOVE_RATE_TRADE = Integer.parseInt(cfg.getProperty("ChatMoveRateTrade", "50"));
               ENABLE_CHAT_MOVE_ONLYPEACE = Boolean.parseBoolean(cfg.getProperty("ChatMoveOnlyPeace", "false"));
               ENABLE_CHAT_KILL = Boolean.parseBoolean(cfg.getProperty("EnableChatKill", "false"));
               FANTOM_CHAT_KILL_RATE = Integer.parseInt(cfg.getProperty("ChatKillRate", "50"));
               FANTOM_CHAT_KILL_RATE_SHOUT = Integer.parseInt(cfg.getProperty("ChatKillRateShout", "50"));
               FANTOM_CHAT_KILL_RATE_TRADE = Integer.parseInt(cfg.getProperty("ChatKillRateTrade", "50"));
               ENABLE_CHAT_DIE = Boolean.parseBoolean(cfg.getProperty("EnableChatDie", "false"));
               FANTOM_CHAT_DIE_RATE = Integer.parseInt(cfg.getProperty("ChatDieRate", "50"));
               FANTOM_CHAT_DIE_RATE_SHOUT = Integer.parseInt(cfg.getProperty("ChatDieRateShout", "50"));
               FANTOM_CHAT_DIE_RATE_TRADE = Integer.parseInt(cfg.getProperty("ChatDieRateTrade", "50"));
            }
         } catch (Exception var10) {
            var10.printStackTrace();
            throw new Error("Failed to Load ./config/fantoms.properties File.");
         }

         loaded = true;
         FantomsManager.getInstance();
      }

   }
}
