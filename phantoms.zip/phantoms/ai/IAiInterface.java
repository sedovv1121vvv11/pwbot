package phantoms.ai;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import phantoms.FantomsManager;

public interface IAiInterface {
   FantomsManager.FantomAi getAiType();

   String toString();

   void setDelay(int var1);

   int getDelay();

   void writeExternal(ObjectOutput var1) throws IOException;

   void readExternal(ObjectInput var1) throws IOException, ClassNotFoundException;
}
