package phantoms.ai;

import java.util.Map;
import javolution.util.FastMap;

public class AiHolder {
   private static AiHolder _instance;
   private Map<String, AiContainer> _ai = new FastMap();
   private int valid;

   public static AiHolder getInstance() {
      if (_instance == null) {
         _instance = new AiHolder();
      }

      return _instance;
   }

   public void increaseValidCounter() {
      ++this.valid;
   }

   public AiContainer getContainer(String key) {
      return (AiContainer)this._ai.get(key);
   }

   public void addAi(String key, IAiInterface ai) {
      ((AiContainer)this._ai.get(key)).addItem(ai, ai.getDelay());
   }

   public void addContainer(String key, AiContainer aic) {
      this._ai.put(key, aic);
   }

   public Map<String, AiContainer> getValues() {
      return this._ai;
   }
}
