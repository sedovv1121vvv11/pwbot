package phantoms.ai;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import net.sf.l2j.Config;

public class AiParser {
   private static AiParser _instance;
   private final FileFilter BIN_FILTER = (f) -> {
      return f.getName().endsWith(".bin");
   };

   public static AiParser getInstance() throws IOException {
      if (_instance == null) {
         _instance = new AiParser();
      }

      return _instance;
   }

   private AiParser() throws IOException {
      this.getHolder();
      File[] var4;
      int var3 = (var4 = this.listFiles()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         File file = var4[var2];

         try {
            if (file.length() > 0L) {
               this.load(file);
            }
         } catch (Exception var6) {
            var6.printStackTrace();
         }
      }

   }

   private void load(File file) {
      ObjectInputStream ois = null;

      try {
         ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
         AiContainer aic = (AiContainer)ois.readObject();
         if (aic.isGoodContainer(true)) {
            this.getHolder().increaseValidCounter();
            this.getHolder().addContainer(file.getName(), aic);
         }
      } catch (EOFException var19) {
      } catch (Exception var20) {
         var20.printStackTrace();
      } finally {
         try {
            if (ois != null) {
               try {
                  ois.close();
               } catch (IOException var17) {
                  var17.printStackTrace();
               }
            }
         } catch (Exception var18) {
            var18.printStackTrace();
         }

      }

   }

   private AiHolder getHolder() {
      return AiHolder.getInstance();
   }

   private File[] listFiles() {
      File file = new File(Config.DATAPACK_ROOT, "config/fantoms/ai");
      return file.listFiles(this.BIN_FILTER);
   }
}
