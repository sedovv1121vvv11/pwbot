package phantoms.ai;

import java.io.Externalizable;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import phantoms.FantomCfg;
import phantoms.FantomsManager;
import phantoms.ai.externalizable.DieSerializable;
import phantoms.ai.externalizable.EnchantItemSerializable;
import phantoms.ai.externalizable.EquipItemSerializable;
import phantoms.ai.externalizable.MountSerializable;
import phantoms.ai.externalizable.MoveToSerializable;
import phantoms.ai.externalizable.RestorePlayerSerializable;
import phantoms.ai.externalizable.TeleToSerializable;

public class AiContainer implements Externalizable {
   private static final long serialVersionUID = -1L;
   protected List<IAiInterface> ai = new LinkedList();
   private long lifeTime;
   private String fileName;
   private int containerFlag = -1;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$phantoms$FantomsManager$FantomAi;

   public void setFileName(String name) {
      this.fileName = name;
   }

   public String getFileName() {
      return this.fileName;
   }

   public IAiInterface get(int i) {
      return this.ai.size() > i ? (IAiInterface)this.ai.get(i) : null;
   }

   public void addItem(IAiInterface item, int time) {
      this.ai.add(item);
      this.lifeTime += (long)time;
   }

   public String toString() {
      return "Container " + this.getClass().getName() + ": " + this.ai.size() + " items";
   }

   public void writeExternal(ObjectOutput out) throws IOException {
      out.writeLong(this.lifeTime);
      out.writeInt(this.ai.size());
      if (this.ai != null && !this.ai.isEmpty()) {
         Iterator var3 = this.ai.iterator();

         while(var3.hasNext()) {
            IAiInterface ext = (IAiInterface)var3.next();
            if (ext != null) {
               out.writeInt(ext.getAiType().ordinal());
               ext.writeExternal(out);
            }
         }
      }

   }

   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
      this.lifeTime = in.readLong();
      int count = in.readInt();

      for(int i = 0; i < count; ++i) {
         IAiInterface ext = this.getAiExtInstance(FantomsManager.FantomAi.values()[in.readInt()]);
         if (ext != null) {
            ext.readExternal(in);
            this.ai.add(ext);
         }
      }

   }

   private IAiInterface getAiExtInstance(FantomsManager.FantomAi ai) {
      switch($SWITCH_TABLE$phantoms$FantomsManager$FantomAi()[ai.ordinal()]) {
      case 2:
         return new MoveToSerializable();
      case 3:
         return new EquipItemSerializable();
      case 4:
         return new EnchantItemSerializable();
      case 5:
         return new TeleToSerializable();
      case 6:
         return new RestorePlayerSerializable();
      case 7:
         return new DieSerializable();
      case 8:
         return new MountSerializable();
      default:
         return null;
      }
   }

   public boolean isGoodContainer(boolean save) {
      if (this.containerFlag == 1) {
         return true;
      } else if (this.containerFlag == 0) {
         return false;
      } else if (this.ai != null && this.ai.size() != 0) {
         if (!((IAiInterface)this.ai.get(0)).getAiType().equals(FantomsManager.FantomAi.RESTORE_PLAYER)) {
            this.containerFlag = 0;
            return false;
         } else if (!this.correctLifeCycle()) {
            if (save) {
               this.containerFlag = 0;
            }

            return false;
         } else {
            RestorePlayerSerializable restore = (RestorePlayerSerializable)this.ai.get(0);
            if (restore.getLvl() >= FantomCfg.FANTOM_LOG_MIN_LVL && restore.getLvl() <= FantomCfg.FANTOM_LOG_MAX_LVL) {
               this.containerFlag = 1;
               return true;
            } else {
               this.containerFlag = 0;
               return false;
            }
         }
      } else {
         this.containerFlag = 0;
         return false;
      }
   }

   private boolean correctLifeCycle() {
      return this.lifeTime >= FantomCfg.FANTOM_LIFE_CYCLE_MAX;
   }

   public File getFile() {
      return new File("config/fantoms/ai/" + this.getFileName());
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$phantoms$FantomsManager$FantomAi() {
      int[] var10000 = $SWITCH_TABLE$phantoms$FantomsManager$FantomAi;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[FantomsManager.FantomAi.values().length];

         try {
            var0[FantomsManager.FantomAi.DIE.ordinal()] = 7;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[FantomsManager.FantomAi.ENCHANT_ITEM.ordinal()] = 4;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[FantomsManager.FantomAi.EQUIP_ITEM.ordinal()] = 3;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[FantomsManager.FantomAi.MOUNT.ordinal()] = 8;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[FantomsManager.FantomAi.MOVE_TO.ordinal()] = 2;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[FantomsManager.FantomAi.NONE.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FantomsManager.FantomAi.RESTORE_PLAYER.ordinal()] = 6;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[FantomsManager.FantomAi.TELE_TO.ordinal()] = 5;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$phantoms$FantomsManager$FantomAi = var0;
         return var0;
      }
   }
}
