package phantoms.ai.externalizable;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import phantoms.FantomsManager;
import phantoms.ai.IAiInterface;

public class RestorePlayerSerializable implements IAiInterface {
   private int activeClassId;
   private boolean female;
   private byte face;
   private byte hairColor;
   private byte hairStyle;
   private long exp;
   private byte lvl;
   private boolean nobless;
   private int recHave;
   private int recLeft;
   private int baseClass;
   private int clanId;
   private int x;
   private int y;
   private int z;

   public RestorePlayerSerializable() {
      this(0, false, (byte)0, (byte)0, (byte)0, 0L, (byte)1, false, 0, 0, 0, 0, 0, 0, 0);
   }

   public RestorePlayerSerializable(int activeClassId, boolean female, byte face, byte hairColor, byte hairStyle, long exp, byte lvl, boolean nobless, int recHave, int recLeft, int baseClass, int clanId, int x, int y, int z) {
      this.activeClassId = activeClassId;
      this.female = female;
      this.face = face;
      this.hairColor = hairColor;
      this.hairStyle = hairStyle;
      this.lvl = lvl;
      this.nobless = nobless;
      this.recHave = recHave;
      this.recLeft = recLeft;
      this.baseClass = baseClass;
      this.clanId = clanId;
      this.x = x;
      this.y = y;
      this.z = z;
   }

   public String toString() {
      return "[" + this.getAiType().toString() + "]";
   }

   public int getActiveClassId() {
      return this.activeClassId;
   }

   public boolean isFemale() {
      return this.female;
   }

   public byte getFace() {
      return this.face;
   }

   public byte getHairColor() {
      return this.hairColor;
   }

   public byte getHairStyle() {
      return this.hairStyle;
   }

   public long getExp() {
      return this.exp;
   }

   public byte getLvl() {
      return this.lvl;
   }

   public boolean isNobless() {
      return this.nobless;
   }

   public int getRecHave() {
      return this.recHave;
   }

   public int getRecLeft() {
      return this.recLeft;
   }

   public int getBaseClass() {
      return this.baseClass;
   }

   public int getClanId() {
      return this.clanId;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public FantomsManager.FantomAi getAiType() {
      return FantomsManager.FantomAi.RESTORE_PLAYER;
   }

   public void setDelay(int delay) {
   }

   public void writeExternal(ObjectOutput out) throws IOException {
      out.writeInt(this.activeClassId);
      out.writeBoolean(this.female);
      out.writeByte(this.face);
      out.writeByte(this.hairColor);
      out.writeByte(this.hairStyle);
      out.writeLong(this.exp);
      out.writeByte(this.lvl);
      out.writeBoolean(this.nobless);
      out.writeInt(this.recHave);
      out.writeInt(this.recLeft);
      out.writeInt(this.baseClass);
      out.writeInt(this.clanId);
      out.writeInt(this.x);
      out.writeInt(this.y);
      out.writeInt(this.z);
   }

   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
      this.activeClassId = in.readInt();
      this.female = in.readBoolean();
      this.face = in.readByte();
      this.hairColor = in.readByte();
      this.hairStyle = in.readByte();
      this.exp = in.readLong();
      this.lvl = in.readByte();
      this.nobless = in.readBoolean();
      this.recHave = in.readInt();
      this.recLeft = in.readInt();
      this.baseClass = in.readInt();
      this.clanId = in.readInt();
      this.x = in.readInt();
      this.y = in.readInt();
      this.z = in.readInt();
   }

   public int getDelay() {
      return 0;
   }
}
