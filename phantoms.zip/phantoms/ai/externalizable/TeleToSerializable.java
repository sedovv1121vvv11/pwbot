package phantoms.ai.externalizable;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import phantoms.FantomsManager;
import phantoms.ai.IAiInterface;

public class TeleToSerializable implements IAiInterface {
   private int x;
   private int y;
   private int z;
   private boolean allowRandomOffset;
   private int delay;

   public TeleToSerializable() {
      this(0, 0, 0, false);
      this.setDelay(0);
   }

   public TeleToSerializable(int x, int y, int z, boolean allowRandomOffset) {
      this.x = x;
      this.y = y;
      this.z = z;
      this.allowRandomOffset = allowRandomOffset;
   }

   public String toString() {
      return "[" + this.getAiType().toString() + "] delay:" + this.getDelay() + " x:" + this.getX() + " y:" + this.getY() + " z:" + this.getZ() + " offset:" + this.isAllowRandomOffset();
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public boolean isAllowRandomOffset() {
      return this.allowRandomOffset;
   }

   public int getDelay() {
      return this.delay;
   }

   public FantomsManager.FantomAi getAiType() {
      return FantomsManager.FantomAi.TELE_TO;
   }

   public void setDelay(int delay) {
      this.delay = delay;
   }

   public void writeExternal(ObjectOutput out) throws IOException {
      out.writeInt(this.x);
      out.writeInt(this.y);
      out.writeInt(this.z);
      out.writeBoolean(this.allowRandomOffset);
      out.writeInt(this.delay);
   }

   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
      this.x = in.readInt();
      this.y = in.readInt();
      this.z = in.readInt();
      this.allowRandomOffset = in.readBoolean();
      this.delay = in.readInt();
   }
}
