package phantoms.ai.externalizable;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import phantoms.FantomsManager;
import phantoms.ai.IAiInterface;

public class EnchantItemSerializable implements IAiInterface {
   private int paperdoll;
   private int enchant;
   private int delay;

   public EnchantItemSerializable() {
      this(0, 0);
      this.setDelay(0);
   }

   public EnchantItemSerializable(int paperdoll, int enchant) {
      this.paperdoll = paperdoll;
      this.enchant = enchant;
   }

   public String toString() {
      return "[" + this.getAiType().toString() + "] delay:" + this.getDelay() + " paperdoll:" + this.getPaperdoll() + " enchant:" + this.getEnchant();
   }

   public int getDelay() {
      return this.delay;
   }

   public int getEnchant() {
      return this.enchant;
   }

   public int getPaperdoll() {
      return this.paperdoll;
   }

   public FantomsManager.FantomAi getAiType() {
      return FantomsManager.FantomAi.ENCHANT_ITEM;
   }

   public void setDelay(int delay) {
      this.delay = delay;
   }

   public void writeExternal(ObjectOutput out) throws IOException {
      out.writeInt(this.paperdoll);
      out.writeInt(this.enchant);
      out.writeInt(this.delay);
   }

   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
      this.paperdoll = in.readInt();
      this.enchant = in.readInt();
      this.delay = in.readInt();
   }
}
