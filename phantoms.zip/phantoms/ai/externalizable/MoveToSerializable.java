package phantoms.ai.externalizable;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import phantoms.FantomsManager;
import phantoms.ai.IAiInterface;

public class MoveToSerializable implements IAiInterface {
   private int delay;
   private int x;
   private int y;
   private int z;

   public MoveToSerializable() {
      this(0, 0, 0);
      this.setDelay(0);
   }

   public MoveToSerializable(int x, int y, int z) {
      this.x = x;
      this.y = y;
      this.z = z;
   }

   public String toString() {
      return "[" + this.getAiType().toString() + "] delay:" + this.getDelay() + " x:" + this.getX() + " y:" + this.getY() + " z:" + this.getZ();
   }

   public int getDelay() {
      return this.delay;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public FantomsManager.FantomAi getAiType() {
      return FantomsManager.FantomAi.MOVE_TO;
   }

   public void setDelay(int delay) {
      this.delay = delay;
   }

   public void writeExternal(ObjectOutput out) throws IOException {
      out.writeInt(this.x);
      out.writeInt(this.y);
      out.writeInt(this.z);
      out.writeInt(this.delay);
   }

   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
      this.x = in.readInt();
      this.y = in.readInt();
      this.z = in.readInt();
      this.delay = in.readInt();
   }
}
