package phantoms.ai.externalizable;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import phantoms.FantomsManager;
import phantoms.ai.IAiInterface;

public class EquipItemSerializable implements IAiInterface {
   private int paperdoll;
   private int itemId;
   private int enchant;
   private int delay;

   public EquipItemSerializable() {
      this(0, 0, 0);
      this.setDelay(0);
   }

   public EquipItemSerializable(int paperdoll, int itemId, int enchant) {
      this.paperdoll = paperdoll;
      this.itemId = itemId;
      this.enchant = enchant;
   }

   public String toString() {
      return "[" + this.getAiType().toString() + "] delay:" + this.getDelay() + " paperdoll:" + this.getPaperdoll() + " itemId:" + this.getItemId() + " enchant:" + this.getEnchant();
   }

   public int getDelay() {
      return this.delay;
   }

   public int getItemId() {
      return this.itemId;
   }

   public int getEnchant() {
      return this.enchant;
   }

   public int getPaperdoll() {
      return this.paperdoll;
   }

   public FantomsManager.FantomAi getAiType() {
      return FantomsManager.FantomAi.EQUIP_ITEM;
   }

   public void setDelay(int delay) {
      this.delay = delay;
   }

   public void writeExternal(ObjectOutput out) throws IOException {
      out.writeInt(this.paperdoll);
      out.writeInt(this.itemId);
      out.writeInt(this.enchant);
      out.writeInt(this.delay);
   }

   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
      this.paperdoll = in.readInt();
      this.itemId = in.readInt();
      this.enchant = in.readInt();
      this.delay = in.readInt();
   }
}
