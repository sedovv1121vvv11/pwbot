package phantoms.ai.externalizable;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import phantoms.FantomsManager;
import phantoms.ai.IAiInterface;

public class DieSerializable implements IAiInterface {
   public FantomsManager.FantomAi getAiType() {
      return FantomsManager.FantomAi.DIE;
   }

   public String toString() {
      return "[" + this.getAiType().toString() + "]";
   }

   public int getDelay() {
      return 0;
   }

   public void setDelay(int delay) {
   }

   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
   }

   public void writeExternal(ObjectOutput out) throws IOException {
   }
}
