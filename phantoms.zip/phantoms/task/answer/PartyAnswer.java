package phantoms.task.answer;

import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.SystemMessage;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;

public class PartyAnswer extends RunnableImpl {
   private L2PcInstance fantom;
   private L2PcInstance requestor;

   public PartyAnswer(L2PcInstance requestor, L2PcInstance fantom) {
      this.fantom = fantom;
      this.requestor = requestor;
   }

   public void runImpl() throws Exception {
      SystemMessage sm = new SystemMessage(SystemMessageId.PLAYER_DECLINED);
      sm.addString(this.fantom.getName());
      this.requestor.sendPacket(sm);
      if (this.requestor.getParty() != null) {
         this.requestor.getParty().decreasePendingInvitationNumber();
      }

      this.fantom.setActiveRequester((L2PcInstance)null);
   }

   protected String getMethodName() {
      return "UnspawnFantom";
   }
}
