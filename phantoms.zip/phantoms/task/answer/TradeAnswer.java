package phantoms.task.answer;

import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;

public class TradeAnswer extends RunnableImpl {
   private L2PcInstance fantom;

   public TradeAnswer(L2PcInstance fantom) {
      this.fantom = fantom;
   }

   public void runImpl() throws Exception {
   }

   protected String getMethodName() {
      return "UnspawnFantom";
   }
}
