package phantoms.task.answer;

import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.SystemMessage;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;

public class PledgeAnswer extends RunnableImpl {
   private L2PcInstance fantom;
   private L2PcInstance requestor;

   public PledgeAnswer(L2PcInstance requestor, L2PcInstance fantom) {
      this.fantom = fantom;
      this.requestor = requestor;
   }

   public void runImpl() throws Exception {
      SystemMessage sm = new SystemMessage(SystemMessageId.S1_DID_NOT_RESPOND_TO_CLAN_INVITATION);
      sm.addString(this.fantom.getName());
      this.requestor.sendPacket(sm);
   }

   protected String getMethodName() {
      return "UnspawnFantom";
   }
}
