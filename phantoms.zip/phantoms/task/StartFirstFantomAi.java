package phantoms.task;

import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;

public class StartFirstFantomAi extends RunnableImpl {
   private L2PcInstance fantom;

   public StartFirstFantomAi(L2PcInstance fantom) {
      this.fantom = fantom;
   }

   public void runImpl() {
      this.fantom.startFantomAi(true);
   }

   protected String getMethodName() {
      return "StartFirstFantomAi";
   }
}
