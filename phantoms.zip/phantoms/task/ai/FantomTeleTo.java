package phantoms.task.ai;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;
import net.sf.l2j.util.Rnd;
import phantoms.FantomCfg;
import phantoms.ai.externalizable.TeleToSerializable;
import phantoms.task.UnspawnFantom;

public class FantomTeleTo extends RunnableImpl {
   private L2PcInstance fantom;
   private int x;
   private int y;
   private int z;
   private boolean offset;

   public FantomTeleTo(L2PcInstance fantom, TeleToSerializable temp) {
      this.fantom = fantom;
      this.x = temp.getX();
      this.y = temp.getY();
      this.z = temp.getZ();
      this.offset = temp.isAllowRandomOffset();
   }

   public void runImpl() throws Exception {
      try {
         if (this.fantom.isDead()) {
            ThreadPoolManager.getInstance().scheduleAi(new UnspawnFantom(this.fantom, true), (long)Rnd.get(FantomCfg.FANTOM_UNSPAWN_INTERVAL_MIN, FantomCfg.FANTOM_UNSPAWN_INTERVAL_MAX), true);
            return;
         }

         try {
            this.fantom.decayMe();
         } catch (Exception var2) {
            var2.printStackTrace();
         }

         if (Config.RESPAWN_RANDOM_ENABLED && this.offset) {
            this.x += Rnd.get(-Config.RESPAWN_RANDOM_MAX_OFFSET, Config.RESPAWN_RANDOM_MAX_OFFSET);
            this.y += Rnd.get(-Config.RESPAWN_RANDOM_MAX_OFFSET, Config.RESPAWN_RANDOM_MAX_OFFSET);
         }

         this.z += 5;
         this.fantom.getPosition().setXYZInvisible(this.x, this.y, this.z);
         this.fantom.spawnMe();
         this.fantom.startFantomAi(true);
         this.fantom.onTeleported();
      } catch (Exception var3) {
         var3.printStackTrace();
      }

   }

   protected String getMethodName() {
      return "FantomTeleTo";
   }
}
