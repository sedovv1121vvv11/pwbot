package phantoms.task.ai;

import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.L2ItemInstance;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;
import net.sf.l2j.util.Rnd;
import phantoms.FantomsManager;
import phantoms.ai.externalizable.EquipItemSerializable;

public class FantomEquipItem extends RunnableImpl {
   private L2PcInstance fantom;
   private int slot;
   private int id;
   private int ench;

   public FantomEquipItem(L2PcInstance fantom, EquipItemSerializable temp) {
      this.fantom = fantom;
      this.slot = temp.getPaperdoll();
      this.id = temp.getItemId();
      this.ench = temp.getEnchant();
   }

   public void runImpl() {
      if (this.id != 0 && FantomsManager.getInstance().isCorrectEquipment(this.id)) {
         L2ItemInstance items = this.fantom.getInventory().addItem("Phantom", this.id, 1, this.fantom, (L2Object)null);
         items.setEnchantLevel(this.ench, true);
         this.fantom.getInventory().equipItemAndRecord(items);
      } else if (this.fantom.getInventory().getPaperdollItem(this.slot) != null) {
         this.fantom.getInventory().unEquipItemInSlotAndRecord(this.slot);
      }

      ThreadPoolManager.getInstance().scheduleAi(() -> {
         FantomsManager.getInstance().handleConsumable(this.fantom, FantomsManager.getInstance().getArrowId(this.fantom));
         FantomsManager.getInstance().handleShots(this.fantom);
      }, (long)Rnd.get(200, 400), true);
      this.fantom.broadcastUserInfo();
      this.fantom.startFantomAi(true);
   }

   protected String getMethodName() {
      return "FantomEquipItem";
   }
}
