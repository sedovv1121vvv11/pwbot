package phantoms.task.ai;

import net.sf.l2j.gameserver.ai.CtrlIntention;
import net.sf.l2j.gameserver.model.L2CharPosition;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;
import phantoms.FantomsManager;
import phantoms.ai.externalizable.MoveToSerializable;

public class FantomMoveTo extends RunnableImpl {
   private L2PcInstance fantom;
   private L2CharPosition cpos;

   public FantomMoveTo(L2PcInstance fantom, MoveToSerializable temp) {
      this.fantom = fantom;
      this.cpos = new L2CharPosition(temp.getX(), temp.getY(), temp.getZ(), 0);
   }

   public void runImpl() {
      FantomsManager.getInstance().chatMove(this.fantom);
      this.fantom.getAI().setIntention(CtrlIntention.AI_INTENTION_MOVE_TO, this.cpos);
      this.fantom.startFantomAi(true);
   }

   protected String getMethodName() {
      return "FantomMoveTo";
   }
}
