package phantoms.task.ai;

import net.sf.l2j.gameserver.model.L2ItemInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;
import phantoms.ai.externalizable.EnchantItemSerializable;

public class FantomEnchantItem extends RunnableImpl {
   private L2PcInstance fantom;
   private int slot;
   private int ench;

   public FantomEnchantItem(L2PcInstance fantom, EnchantItemSerializable temp) {
      this.fantom = fantom;
      this.slot = temp.getPaperdoll();
      this.ench = temp.getEnchant();
   }

   public void runImpl() {
      L2ItemInstance item = this.fantom.getInventory().getPaperdollItem(this.slot);
      if (item != null) {
         item.setEnchantLevel(this.ench);
         this.fantom.broadcastUserInfo();
      }

      this.fantom.startFantomAi(true);
   }

   protected String getMethodName() {
      return "FantomEquipItem";
   }
}
