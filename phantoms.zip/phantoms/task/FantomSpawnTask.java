package phantoms.task;

import java.util.Iterator;
import java.util.logging.Logger;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;
import net.sf.l2j.util.Rnd;
import net.sf.l2j.util.log.AbstractLogger;
import phantoms.FantomCfg;
import phantoms.FantomsManager;

public class FantomSpawnTask extends RunnableImpl {
   private static final Logger _log = AbstractLogger.getLogger(FantomSpawnTask.class.getName());
   private int SPAWN_TYPE;

   public FantomSpawnTask(int type) {
      this.SPAWN_TYPE = type;
   }

   public void runImpl() {
      if (!FantomsManager.getInstance().isSpawning()) {
         FantomsManager.getInstance().setIsSpawning(true);
         long rndInterval = 0L;
         int i;
         label51:
         switch(this.SPAWN_TYPE) {
         case 1:
            try {
               i = 0;

               while(true) {
                  if (i >= FantomCfg.FANTOM_SPAWN_COUNT) {
                     break label51;
                  }

                  String fantomAiLifeCycle = FantomsManager.getInstance().getRndLifeCycle();
                  rndInterval = (long)Rnd.get(FantomCfg.FANTOM_SPAWN_INTERVAL_MIN, FantomCfg.FANTOM_SPAWN_INTERVAL_MAX);
                  ThreadPoolManager.getInstance().scheduleAi(new SpawnFantom(fantomAiLifeCycle, (long)Rnd.get(FantomCfg.FANTOM_LIFE_CYCLE_MIN / 1000L, FantomCfg.FANTOM_LIFE_CYCLE_MAX)), rndInterval, true);
                  Thread.sleep(rndInterval);
                  ++i;
               }
            } catch (Exception var9) {
               _log.warning("FantomSpawnTask.runImpl1");
               var9.printStackTrace();
               break;
            }
         case 2:
            i = L2World.getInstance().getLiveOnline() * FantomCfg.FANTOM_SPAWN_COUNT / 100;
            int fantomsCount = L2World.getInstance().getFantoms().size();
            int temp = false;
            int temp;
            if (fantomsCount > i) {
               temp = fantomsCount - i;
               Iterator var7 = L2World.getInstance().getFantoms().iterator();

               while(var7.hasNext()) {
                  L2PcInstance fantom = (L2PcInstance)var7.next();
                  if (temp == 0) {
                     break;
                  }

                  --temp;
                  ThreadPoolManager.getInstance().scheduleAi(new UnspawnFantom(fantom, false), (long)Rnd.get(FantomCfg.FANTOM_UNSPAWN_INTERVAL_MIN, FantomCfg.FANTOM_UNSPAWN_INTERVAL_MAX), true);
               }
            } else {
               temp = i - fantomsCount;

               try {
                  for(int i = 0; i < temp; ++i) {
                     String fantomAiLifeCycle = FantomsManager.getInstance().getRndLifeCycle();
                     rndInterval = (long)Rnd.get(FantomCfg.FANTOM_SPAWN_INTERVAL_MIN, FantomCfg.FANTOM_SPAWN_INTERVAL_MAX);
                     ThreadPoolManager.getInstance().scheduleAi(new SpawnFantom(fantomAiLifeCycle, (long)Rnd.get(FantomCfg.FANTOM_LIFE_CYCLE_MIN, FantomCfg.FANTOM_LIFE_CYCLE_MAX)), rndInterval, true);
                     Thread.sleep(rndInterval);
                  }
               } catch (Exception var8) {
                  _log.warning("FantomSpawnTask.runImpl");
                  var8.printStackTrace();
               }
            }
         }

         FantomsManager.getInstance().setIsSpawning(false);
      }
   }

   protected String getMethodName() {
      return "FantomSpawnTask";
   }
}
