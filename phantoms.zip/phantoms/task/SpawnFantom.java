package phantoms.task;

import java.util.logging.Logger;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.L2ItemInstance;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUser;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.util.Rnd;
import net.sf.l2j.util.log.AbstractLogger;
import phantoms.FantomCfg;
import phantoms.FantomsManager;
import phantoms.ai.AiContainer;
import phantoms.ai.AiHolder;
import phantoms.ai.IAiInterface;
import phantoms.ai.externalizable.EquipItemSerializable;
import phantoms.ai.externalizable.RestorePlayerSerializable;

public class SpawnFantom extends RunnableImpl {
   private static final Logger _log = AbstractLogger.getLogger(SpawnFantom.class.getName());
   private String ai;
   private long lc;
   private int[] M_SKILL_IDS = new int[]{2061, 2160, 2161, 2162, 2163, 2164};
   private int[] F_SKILL_IDS = new int[]{2061, 2155, 2156, 2157, 2158, 2159};

   public SpawnFantom(String fantomAiLifeCycle, long lifeCycle) {
      this.ai = fantomAiLifeCycle;
      this.lc = lifeCycle;
   }

   public void runImpl() {
      if (this.ai != null && !this.ai.isEmpty()) {
         AiContainer val = AiHolder.getInstance().getContainer(this.ai);
         int itAi = 0;
         IAiInterface temp = val.get(itAi);
         L2PcInstance fantom = null;
         if (temp != null && temp.getAiType() != null) {
            for(; temp != null && temp.getAiType() != null && (temp.getAiType().equals(FantomsManager.FantomAi.RESTORE_PLAYER) || temp.getAiType().equals(FantomsManager.FantomAi.EQUIP_ITEM)); temp = val.get(itAi++)) {
               if (temp.getAiType().equals(FantomsManager.FantomAi.RESTORE_PLAYER)) {
                  fantom = L2PcInstance.restoreFantom((RestorePlayerSerializable)temp);
                  if (fantom == null) {
                     return;
                  }

                  try {
                     fantom.setName(this.getRndName(fantom));
                     fantom.setTitle(this.getRndTitle(fantom));
                  } catch (NullPointerException var9) {
                     _log.warning("SpawnFantom: error");
                     var9.printStackTrace();
                     return;
                  }
               } else if (temp.getAiType().equals(FantomsManager.FantomAi.EQUIP_ITEM)) {
                  EquipItemSerializable ei = (EquipItemSerializable)temp;
                  int id = ei.getItemId();
                  int ench = ei.getEnchant();
                  if (id != 0 && FantomsManager.getInstance().isCorrectEquipment(id)) {
                     L2ItemInstance items = fantom.getInventory().addItem("Phantom", id, 1, fantom, (L2Object)null);
                     if (ench > 0) {
                        items.setEnchantLevel(ench, true);
                     }

                     fantom.getInventory().equipItemAndRecord(items);
                     FantomsManager.getInstance().handleConsumable(fantom, FantomsManager.getInstance().getArrowId(fantom));
                  }
               }
            }

            fantom.setFantomAi(this.ai, itAi);
            fantom.setFantomLC(this.lc);
            FantomsManager.getInstance().addFantom(fantom);
            fantom.rewardSkills();
            fantom.setRunning();
            if (FantomCfg.FANTOM_BUFFS) {
               FantomsManager.getInstance().AddBuff(fantom);
            }

            fantom.spawnMe();
            FantomsManager.getInstance().handleShots(fantom);
            fantom.broadcastUserInfo();
            ThreadPoolManager.getInstance().scheduleAi(new StartFirstFantomAi(fantom), (long)Rnd.get(FantomCfg.FANTOM_FIRST_AI_MIN, FantomCfg.FANTOM_FIRST_AI_MAX), true);
         }
      }
   }

   private void phantomShotActivate(L2PcInstance phantom) {
      L2ItemInstance item = phantom.getActiveWeaponInstance();
      if (item != null) {
         int shot_id;
         if (phantom.isMageClass()) {
            shot_id = this.getBlessedSpiritShotIdByWeaponGrade(item);
         } else {
            shot_id = this.getSoulShotIdByWeaponGrade(item);
         }

         if (shot_id == 0) {
            _log.warning("Soulshot/spiritshot is null");
         }

         phantom.getInventory().addItem("Phantom", shot_id, 500, phantom, (L2Object)null);
         if (shot_id != 0) {
            phantom.addAutoSoulShot(shot_id);
         }

         phantom.rechargeAutoSoulShot(true, true, false);
         L2ItemInstance weaponInst = phantom.getActiveWeaponInstance();
         int grade = weaponInst.getItem().getCrystalType();
         if (phantom.isMageClass()) {
            Broadcast.toSelfAndKnownPlayersInRadius(phantom, new MagicSkillUser(phantom, phantom, this.M_SKILL_IDS[grade], 1, 0, 0), 600L);
         } else {
            Broadcast.toSelfAndKnownPlayersInRadius(phantom, new MagicSkillUser(phantom, phantom, this.F_SKILL_IDS[grade], 1, 0, 0), 600L);
         }
      }

   }

   private int getSoulShotIdByWeaponGrade(L2ItemInstance item) {
      int grade = item.getItem().getCrystalType();
      if (grade == 0) {
         return 1835;
      } else if (grade == 1) {
         return 1463;
      } else if (grade == 2) {
         return 1464;
      } else if (grade == 3) {
         return 1465;
      } else if (grade == 4) {
         return 1466;
      } else {
         return grade == 5 ? 1467 : 0;
      }
   }

   private int getBlessedSpiritShotIdByWeaponGrade(L2ItemInstance item) {
      int grade = item.getItem().getCrystalType();
      if (grade == 0) {
         return 3947;
      } else if (grade == 1) {
         return 3948;
      } else if (grade == 2) {
         return 3949;
      } else if (grade == 3) {
         return 3950;
      } else if (grade == 4) {
         return 3951;
      } else {
         return grade == 5 ? 3952 : 0;
      }
   }

   private String getRndTitle(L2PcInstance fantom) {
      if (!Config.STARTUP_TITLE.equalsIgnoreCase("off") && fantom.getClan() == null && !fantom.isNoble()) {
         return Config.STARTUP_TITLE;
      } else {
         return (Rnd.get(100) > FantomCfg.FANTOM_TITLE_CHANCE || fantom.getClan() == null) && !fantom.isNoble() ? "" : FantomsManager.getInstance().getRndTitle(fantom.getAppearance().getSex());
      }
   }

   private String getRndName(L2PcInstance fantom) {
      return FantomsManager.getInstance().getRndName(fantom.getAppearance().getSex());
   }

   protected String getMethodName() {
      return "SpawnFantom";
   }
}
