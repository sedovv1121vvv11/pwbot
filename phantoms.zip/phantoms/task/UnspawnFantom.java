package phantoms.task;

import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.taskmanager.utils.RunnableImpl;
import phantoms.FantomCfg;
import phantoms.FantomsManager;

public class UnspawnFantom extends RunnableImpl {
   private L2PcInstance fantom;
   private boolean spawnNew;

   public UnspawnFantom(L2PcInstance fantom, boolean spawnNew) {
      this.fantom = fantom;
      this.spawnNew = spawnNew;
   }

   public void runImpl() throws Exception {
      if (this.fantom.isMoving()) {
         ThreadPoolManager.getInstance().scheduleAi(new UnspawnFantom(this.fantom, this.spawnNew), FantomCfg.FANTOM_AI_MAX_TIME, true);
      } else {
         if (this.fantom.isDead()) {
            FantomsManager.getInstance().chatDie(this.fantom);
         }

         L2World.getInstance().removePlayer(this.fantom);
         this.fantom.fantomUnspawn(this.spawnNew);
      }
   }

   protected String getMethodName() {
      return "UnspawnFantom";
   }
}
