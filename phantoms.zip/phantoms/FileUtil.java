package phantoms;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class FileUtil {
   public static void write(String path, String text, boolean ln, boolean date) {
      try {
         if (date) {
            text = "[" + (new SimpleDateFormat("HH:mm:ss dd.MM")).format(new Date()) + "]\t" + text;
         }

         if (ln) {
            text = text + "\n";
         }

         if (path.contains("/")) {
            checkDirs(path);
         }

         File file = new File(path);
         if (!file.exists()) {
            file.createNewFile();
         }

         FileWriter fw = new FileWriter(file, true);
         fw.write(text);
         fw.flush();
         fw.close();
      } catch (IOException var6) {
         var6.printStackTrace();
      }

   }

   public static void write(String path, String message) {
      write(path, message, true, true);
   }

   public static void write(String path) {
      write(path, "", false, false);
   }

   public static void checkDirs(String path) {
      StringBuilder folderPath = new StringBuilder();
      String[] splitPath = path.split("/");

      for(int i = 0; i < splitPath.length - 1; ++i) {
         folderPath.append(splitPath[i]).append("/");
      }

      File dir = new File(folderPath.toString());
      if (!dir.exists()) {
         dir.mkdirs();
      }

   }

   public static ArrayList<String> read(String filename, String comment, boolean inlineComment) {
      ArrayList<String> result = new ArrayList();
      File file = new File(filename);
      if (!file.exists()) {
         return result;
      } else {
         BufferedReader reader = null;

         try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));

            while(true) {
               String line;
               do {
                  do {
                     if ((line = reader.readLine()) == null) {
                        return result;
                     }
                  } while(line.length() < 1);
               } while(comment != null && line.startsWith(comment));

               if (inlineComment && comment != null && line.contains(comment)) {
                  line = line.substring(0, line.indexOf(comment));
               }

               result.add(line);
            }
         } catch (Exception var18) {
            var18.printStackTrace();

            try {
               if (reader != null) {
                  reader.close();
               }
            } catch (IOException var17) {
               var17.printStackTrace();
            }
         } finally {
            try {
               if (reader != null) {
                  reader.close();
               }
            } catch (IOException var16) {
               var16.printStackTrace();
            }

         }

         return result;
      }
   }
}
