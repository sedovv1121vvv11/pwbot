package phantoms;

import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import javolution.util.FastMap;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.CharNameTable;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.instancemanager.TownManager;
import net.sf.l2j.gameserver.model.L2Character;
import net.sf.l2j.gameserver.model.L2ItemInstance;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.player.PlayerListenerList;
import net.sf.l2j.gameserver.network.serverpackets.CreatureSay;
import net.sf.l2j.gameserver.templates.L2Item;
import net.sf.l2j.util.Rnd;
import net.sf.l2j.util.log.AbstractLogger;
import org.apache.commons.io.FileUtils;
import phantoms.ai.AiContainer;
import phantoms.ai.AiHolder;
import phantoms.ai.AiParser;
import phantoms.ai.IAiInterface;
import phantoms.listeners.OnDie;
import phantoms.listeners.PlayerEnter;
import phantoms.listeners.PlayerExit;
import phantoms.task.FantomSpawnTask;
import scripts.zone.type.L2TownZone;

public class FantomsManager {
   private static final Logger _log = AbstractLogger.getLogger(FantomsManager.class.getName());
   private static FantomsManager _instance;
   private Map<Integer, Long> _lastTimeAi;
   private Map<Integer, Long> _playerLoggingTimeAi;
   private FastMap<Integer, File> _playerLoggingFile;
   public static String default_path = "config/fantoms/";
   private Map<Integer, L2PcInstance> _fantoms;
   private List<String> _fakeNickReserved;
   private List<String> _nameMaleList;
   private List<String> _nameFemaleList;
   private List<String> _tittleMaleList;
   private List<String> _tittleFemaleList;
   private boolean isSpawning;
   private boolean _isUpdatingFiles;
   private List<String> _used;
   private Iterator<Entry<String, AiContainer>> _iteratorAi;
   private List<String> _movetxt;
   private List<String> _killtxt;
   private List<String> _dietxt;
   private List<String> _fakesPMPhrases;
   // $FF: synthetic field
   private static volatile int[] $SWITCH_TABLE$phantoms$FantomsManager$FantomAi;

   public boolean isSpawning() {
      return this.isSpawning;
   }

   public void setIsSpawning(boolean v) {
      this.isSpawning = v;
   }

   private void setIsUpdatingFiles(boolean b) {
      this._isUpdatingFiles = b;
   }

   public boolean isUpdatingFiles() {
      return this._isUpdatingFiles;
   }

   public static FantomsManager getInstance() {
      if (_instance == null) {
         _instance = new FantomsManager();
      }

      return _instance;
   }

   private FantomsManager() {
      if (FantomCfg.ENABLE_FANTOMS) {
         this._playerLoggingFile = new FastMap();
         this._playerLoggingTimeAi = new FastMap();
         this._lastTimeAi = new ConcurrentHashMap();
         this._fantoms = new FastMap();
         this._fakeNickReserved = new ArrayList();
         this._used = new ArrayList();

         try {
            this._movetxt = new ArrayList(FileUtils.readLines(new File(default_path + "chat/chat.txt")));
            this._killtxt = new ArrayList(FileUtils.readLines(new File(default_path + "chat/kill.txt")));
            this._dietxt = new ArrayList(FileUtils.readLines(new File(default_path + "chat/die.txt")));
            this._fakesPMPhrases = new ArrayList(FileUtils.readLines(new File(default_path + "chat/pm.txt")));
            this._nameMaleList = new ArrayList(FileUtils.readLines(new File(default_path + "male_names.txt")));
            this._nameFemaleList = new ArrayList(FileUtils.readLines(new File(default_path + "female_names.txt")));
            this._tittleMaleList = new ArrayList(FileUtils.readLines(new File(default_path + "male_titles.txt")));
            this._tittleFemaleList = new ArrayList(FileUtils.readLines(new File(default_path + "female_titles.txt")));
         } catch (Exception var3) {
         }

         if (FantomCfg.FANTOM_ENABLE_CREATING_AI) {
            PlayerListenerList.addGlobal(new PlayerEnter());
            PlayerListenerList.addGlobal(new PlayerExit());
            PlayerListenerList.addGlobal(new OnDie());
         }

         FantomsClanManager.getInstance();

         try {
            AiParser.getInstance();
         } catch (IOException var2) {
            var2.printStackTrace();
         }

         if (FantomCfg.FANTOM_SPAWN) {
            switch(FantomCfg.FANTOM_SPAWN_TYPE) {
            case 1:
               ThreadPoolManager.getInstance().scheduleGeneral(new FantomSpawnTask(FantomCfg.FANTOM_SPAWN_TYPE), FantomCfg.FANTOM_START_SPAWN_INTERVAL);
               break;
            case 2:
               ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(new FantomSpawnTask(FantomCfg.FANTOM_SPAWN_TYPE), FantomCfg.FANTOM_START_SPAWN_INTERVAL, FantomCfg.FANTOM_START_SPAWN_INTERVAL);
               break;
            default:
               _log.warning("FantomsManager: Spawn type must be 1 or 2");
            }
         }

         _log.info("FantomsManager: loaded " + AiHolder.getInstance().getValues().size() + " ai's.");
      }

   }

   public void writePlayerAI(L2PcInstance player, IAiInterface ai) {
      if (FantomCfg.FANTOM_ENABLE_CREATING_AI && !player.isInOlympiadMode() && !player.isInEvent() && !player.inObserverMode() && !player.isPhantoms()) {
         if (player.isInZonePeace()) {
            L2TownZone town = TownManager.getTown(player.getX(), player.getY(), player.getZ());
            if (town != null) {
               this.writePlayerAI(player.getObjectId(), ai);
            }
         }

      }
   }

   private void writePlayerAI(int objId, IAiInterface ai) {
      if (FantomCfg.ENABLE_FANTOMS && FantomCfg.FANTOM_ENABLE_CREATING_AI) {
         if (this._playerLoggingFile.containsKey(objId)) {
            long time;
            try {
               time = System.currentTimeMillis() - (Long)this._lastTimeAi.get(objId);
            } catch (Exception var6) {
               time = (long)Rnd.get(500, 5000);
            }

            switch($SWITCH_TABLE$phantoms$FantomsManager$FantomAi()[ai.getAiType().ordinal()]) {
            case 2:
            case 3:
            case 4:
            case 5:
               ai.setDelay((int)time);
            default:
               this._lastTimeAi.put(objId, System.currentTimeMillis());
               this._playerLoggingTimeAi.put(objId, (Long)this._playerLoggingTimeAi.get(objId) + time);
               AiHolder.getInstance().addAi(((File)this._playerLoggingFile.get(objId)).getName(), ai);
            }
         }
      }
   }

   public String getRndTitle(boolean isFemale) {
      return (String)(isFemale ? this._tittleFemaleList : this._tittleMaleList).get(Rnd.get((isFemale ? this._tittleFemaleList : this._tittleMaleList).size()));
   }

   public String getRndName(boolean isFemale) {
      String name = (String)(isFemale ? this._nameFemaleList : this._nameMaleList).get(Rnd.get((isFemale ? this._nameFemaleList : this._nameMaleList).size()));
      if (!CharNameTable.getInstance().doesCharNameExist(name) && !this._fakeNickReserved.contains(name)) {
         this._fakeNickReserved.add(name);
         return name;
      } else {
         return this.getRndName(isFemale);
      }
   }

   public String getRandomPMPhrase() {
      return (String)this._fakesPMPhrases.get(Rnd.get(this._fakesPMPhrases.size() - 1));
   }

   private String getRndMoveTxt() {
      return (String)this._movetxt.get(Rnd.get(this._movetxt.size()));
   }

   private String getRndKillTxt() {
      return (String)this._killtxt.get(Rnd.get(this._killtxt.size()));
   }

   private String getRndDieTxt() {
      return (String)this._dietxt.get(Rnd.get(this._dietxt.size()));
   }

   public void addFantom(L2PcInstance fantom) {
      this._fakeNickReserved.add(fantom.getName());
      this._fantoms.put(fantom.getObjectId(), fantom);
   }

   public long getFantomDelay(long delay) {
      if (delay < 100L) {
         return 100L;
      } else {
         return delay > FantomCfg.FANTOM_AI_MAX_TIME ? FantomCfg.FANTOM_AI_MAX_TIME : delay;
      }
   }

   public void setUsed(String val, boolean v) {
      if (v) {
         this._used.add(val);
      } else {
         this._used.remove(val);
      }

   }

   private boolean isUsed(String val) {
      return this._used.contains(val);
   }

   public String getRndLifeCycle() {
      while(this.isUpdatingFiles()) {
         try {
            Thread.sleep(1000L);
         } catch (InterruptedException var2) {
            var2.printStackTrace();
         }
      }

      if (this._iteratorAi == null) {
         this.updateAiFileList();
      }

      if (this._iteratorAi.hasNext()) {
         Entry<String, AiContainer> val = (Entry)this._iteratorAi.next();
         if (((AiContainer)val.getValue()).isGoodContainer(false) && !this.isUsed((String)val.getKey())) {
            this.setUsed((String)val.getKey(), true);
            return (String)val.getKey();
         } else {
            return this.getRndLifeCycle();
         }
      } else {
         this._iteratorAi = null;
         return null;
      }
   }

   public void removeFantom(L2PcInstance fantom) {
      this._fantoms.remove(fantom.getObjectId());
   }

   public boolean isCorrectEquipment(int id) {
      if (FantomCfg.FANTOM_RESTRICT_EQUIPMENT.contains(id)) {
         return false;
      } else {
         L2Item item = ItemTable.getInstance().getTemplate(id);
         return item != null && !isHeroItem(id);
      }
   }

   private static boolean isHeroItem(int _itemId) {
      return _itemId >= 6611 && _itemId <= 6621 || _itemId == 6842;
   }

   public void endLogging(int objId) {
      File f = (File)this._playerLoggingFile.get(objId);
      if (f != null) {
         AiContainer container = AiHolder.getInstance().getContainer(f.getName());
         if (container != null && container.isGoodContainer(true)) {
            ObjectOutputStream oos = null;

            try {
               oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream((File)this._playerLoggingFile.get(objId))));
               oos.writeObject(container);
               oos.flush();
               this._playerLoggingTimeAi.remove(objId);
            } catch (EOFException var21) {
               var21.printStackTrace();
            } catch (Exception var22) {
               var22.printStackTrace();
            } finally {
               try {
                  if (oos != null) {
                     try {
                        oos.close();
                     } catch (IOException var19) {
                        var19.printStackTrace();
                     }
                  }
               } catch (Exception var20) {
                  var20.printStackTrace();
               }

            }
         }

         this._playerLoggingFile.remove(objId);
      }
   }

   public boolean isLogging(int objId) {
      return this._playerLoggingFile.containsKey(objId);
   }

   public void startLogging(int objId) {
      String path = default_path + "ai/" + UUID.randomUUID().toString() + ".bin";
      if (path.contains("/")) {
         FileUtil.checkDirs(path);
      }

      File file = new File(path);
      this._playerLoggingFile.put(objId, file);
      AiHolder.getInstance().addContainer(file.getName(), new AiContainer());
      if (!this._playerLoggingTimeAi.containsKey(objId)) {
         this._playerLoggingTimeAi.put(objId, 0L);
      }

   }

   public void chatDie(L2PcInstance fantom) {
      if (FantomCfg.ENABLE_CHAT_DIE) {
         byte chat;
         if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_DIE_RATE_SHOUT) {
            chat = 1;
         } else if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_DIE_RATE_TRADE) {
            chat = 8;
         } else {
            chat = 0;
         }

         if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_DIE_RATE) {
            CreatureSay cs = new CreatureSay(fantom.getObjectId(), chat, fantom.getName(), this.getRndDieTxt());
            fantom.broadcastPacket(cs);
         }
      }

   }

   public void chatKill(L2PcInstance fantom, L2Object target) {
      if (FantomCfg.ENABLE_CHAT_KILL && target.isPlayer()) {
         byte chat;
         if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_KILL_RATE_SHOUT) {
            chat = 1;
         } else if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_KILL_RATE_TRADE) {
            chat = 8;
         } else {
            chat = 0;
         }

         if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_KILL_RATE) {
            CreatureSay cs = new CreatureSay(fantom.getObjectId(), chat, fantom.getName(), this.getRndKillTxt());
            fantom.broadcastPacket(cs);
         }
      }

   }

   public void chatMove(L2PcInstance fantom) {
      if (FantomCfg.ENABLE_CHAT_MOVE) {
         byte chat;
         if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_MOVE_RATE_SHOUT) {
            chat = 1;
         } else if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_MOVE_RATE_TRADE) {
            chat = 8;
         } else {
            chat = 0;
         }

         if (Rnd.get(100) < FantomCfg.FANTOM_CHAT_MOVE_RATE && FantomCfg.ENABLE_CHAT_MOVE_ONLYPEACE && fantom.isInZonePeace()) {
            CreatureSay cs = new CreatureSay(fantom.getObjectId(), chat, fantom.getName(), getInstance().getRndMoveTxt());
            fantom.broadcastPacket(cs);
         }
      }

   }

   public void updateAiFileList() {
      this.setIsUpdatingFiles(true);
      this._iteratorAi = AiHolder.getInstance().getValues().entrySet().iterator();
      this.setIsUpdatingFiles(false);
   }

   public void handleConsumable(L2PcInstance fakePlayer, int consumableId) {
      if (fakePlayer.getInventory().getItemByItemId(consumableId) != null) {
         if (fakePlayer.getInventory().getItemByItemId(consumableId).getCount() <= 20) {
            fakePlayer.getInventory().addItem("", consumableId, 500, fakePlayer, (L2Object)null);
         }
      } else {
         fakePlayer.getInventory().addItem("", consumableId, 500, fakePlayer, (L2Object)null);
         L2ItemInstance consumable = fakePlayer.getInventory().getItemByItemId(consumableId);
         if (consumable.isEquipable()) {
            fakePlayer.getInventory().equipItem(consumable);
         }
      }

   }

   private int getShotId(L2PcInstance fantom) {
      int playerLevel = fantom.getLevel();
      if (playerLevel < 20) {
         return !fantom.isMageClass() ? 1835 : 3947;
      } else if (playerLevel >= 20 && playerLevel < 40) {
         return !fantom.isMageClass() ? 1463 : 3948;
      } else if (playerLevel >= 40 && playerLevel < 52) {
         return !fantom.isMageClass() ? 1464 : 3949;
      } else if (playerLevel >= 52 && playerLevel < 61) {
         return !fantom.isMageClass() ? 1465 : 3950;
      } else if (playerLevel >= 61 && playerLevel < 76) {
         return !fantom.isMageClass() ? 1466 : 3951;
      } else if (playerLevel >= 76) {
         return !fantom.isMageClass() ? 1467 : 3952;
      } else {
         return 0;
      }
   }

   public void handleShots(L2PcInstance player) {
      if (player.getInventory().getItemByItemId(this.getShotId(player)) != null) {
         if (player.getInventory().getItemByItemId(this.getShotId(player)).getCount() <= 20) {
            player.getInventory().addItem("", this.getShotId(player), 500, player, (L2Object)null);
         }
      } else {
         player.getInventory().addItem("", this.getShotId(player), 500, player, (L2Object)null);
      }

      if (player.getAutoSoulShot().isEmpty()) {
         player.addAutoSoulShot(this.getShotId(player));
         player.rechargeAutoSoulShot(true, true, false);
      }

   }

   public int getArrowId(L2PcInstance fantom) {
      int playerLevel = fantom.getLevel();
      if (playerLevel < 20) {
         return 17;
      } else if (playerLevel >= 20 && playerLevel < 40) {
         return 1341;
      } else if (playerLevel >= 40 && playerLevel < 52) {
         return 1342;
      } else if (playerLevel >= 52 && playerLevel < 61) {
         return 1343;
      } else if (playerLevel >= 61 && playerLevel < 76) {
         return 1344;
      } else {
         return playerLevel >= 76 ? 1345 : 0;
      }
   }

   public void removeReservedNick(String name) {
      this._fakeNickReserved.remove(name);
   }

   public void AddBuff(L2PcInstance player) {
      Iterator var3 = (player.isMageClass() ? FantomCfg.FANTOM_M_BUFFS : FantomCfg.FANTOM_F_BUFFS).iterator();

      while(var3.hasNext()) {
         String asd = (String)var3.next();
         String[] werty = asd.split(",");
         L2Skill skill = SkillTable.getInstance().getInfo(Integer.parseInt(werty[0]), Integer.parseInt(werty[1]));
         if (skill != null) {
            skill.getEffects(player, player);
         }
      }

      this.heal(player);
   }

   private void heal(L2Character player) {
      player.getStatus().setCurrentCp((double)player.getMaxCp());
      player.getStatus().setCurrentMp((double)player.getMaxMp());
      player.getStatus().setCurrentHp((double)player.getMaxHp());
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$phantoms$FantomsManager$FantomAi() {
      int[] var10000 = $SWITCH_TABLE$phantoms$FantomsManager$FantomAi;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[FantomsManager.FantomAi.values().length];

         try {
            var0[FantomsManager.FantomAi.DIE.ordinal()] = 7;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[FantomsManager.FantomAi.ENCHANT_ITEM.ordinal()] = 4;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[FantomsManager.FantomAi.EQUIP_ITEM.ordinal()] = 3;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[FantomsManager.FantomAi.MOUNT.ordinal()] = 8;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[FantomsManager.FantomAi.MOVE_TO.ordinal()] = 2;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[FantomsManager.FantomAi.NONE.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FantomsManager.FantomAi.RESTORE_PLAYER.ordinal()] = 6;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[FantomsManager.FantomAi.TELE_TO.ordinal()] = 5;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$phantoms$FantomsManager$FantomAi = var0;
         return var0;
      }
   }

   public static enum FantomAi {
      NONE,
      MOVE_TO,
      EQUIP_ITEM,
      ENCHANT_ITEM,
      TELE_TO,
      RESTORE_PLAYER,
      DIE,
      MOUNT;
   }
}
