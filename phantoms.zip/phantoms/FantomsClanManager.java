package phantoms;

import java.io.File;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javolution.util.FastMap;
import javolution.util.FastTable;
import net.sf.l2j.gameserver.datatables.ClanTable;
import net.sf.l2j.gameserver.model.L2Clan;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.util.Rnd;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class FantomsClanManager {
   private static FantomsClanManager _instance;
   private Logger _log = Logger.getLogger(FantomsClanManager.class);
   private Map<Integer, L2Clan> _inheritClans = new FastMap();

   public static FantomsClanManager getInstance() {
      if (_instance == null) {
         _instance = new FantomsClanManager();
      }

      return _instance;
   }

   private void createAlly(L2Clan clanInherit, L2Clan clanFantom) {
      if (clanInherit.getAllyId() != 0) {
         Iterator var4 = this._inheritClans.keySet().iterator();

         while(var4.hasNext()) {
            int inheritClanId = (Integer)var4.next();
            L2Clan temp = ClanTable.getInstance().getClan(inheritClanId);
            if (temp == null) {
               return;
            }

            if (clanInherit.getAllyId() == temp.getAllyId()) {
               clanFantom.setAllyId(((L2Clan)this._inheritClans.get(inheritClanId)).getAllyId());
               clanFantom.setAllyName(((L2Clan)this._inheritClans.get(inheritClanId)).getAllyName());
               clanFantom.setAllyCrestId(((L2Clan)this._inheritClans.get(inheritClanId)).getAllyCrestId());
               return;
            }
         }
      }

      clanFantom.setAllyId(clanFantom.getClanId());
      clanFantom.setAllyName(this.getRndAllyName());
   }

   private void setLargeCrest(L2Clan clanFantom) {
      clanFantom.setHasCrestLarge(true);
   }

   private void setCrest(L2Clan clanFantom) {
      clanFantom.setHasCrest(true);
   }

   private String getRndClanName() {
      try {
         File names = new File(FantomsManager.default_path + "clan_names.txt");
         List<String> lines = FileUtils.readLines(names);
         Iterator var4 = FileUtils.readLines(names).iterator();

         while(var4.hasNext()) {
            String name = (String)var4.next();
            name = (String)lines.get(Rnd.get(lines.size()));
            if (ClanTable.getInstance().getClanByName(name) == null) {
               return name;
            }
         }
      } catch (Exception var5) {
         this._log.warn("FantomClanManager.getRndClanName", var5);
      }

      return String.valueOf(Rnd.get(100000, 999999));
   }

   private String getRndAllyName() {
      try {
         File names = new File(FantomsManager.default_path + "ally_names.txt");
         List<?> lines = FileUtils.readLines(names);
         Iterator var4 = FileUtils.readLines(names).iterator();

         while(var4.hasNext()) {
            String name = (String)var4.next();
            name = lines.get(Rnd.get(lines.size())).toString();
            if (ClanTable.getInstance().getClanByName(name) == null) {
               return name;
            }
         }
      } catch (Exception var5) {
         this._log.warn("FantomClanManager.getRndAllyName", var5);
      }

      return String.valueOf(Rnd.get(100000, 999999));
   }

   public void setClan(L2PcInstance player, int clanId) {
      if (Rnd.chance(50)) {
         FastTable<L2Clan> clans = new FastTable();
         Iterator var5 = ClanTable.getInstance().getClans().iterator();

         L2Clan clan;
         while(var5.hasNext()) {
            clan = (L2Clan)var5.next();
            if (clan.isFantomClan()) {
               clans.add(clan);
            }
         }

         if (clans.size() > 0) {
            Collections.shuffle(clans);
            clan = (L2Clan)clans.get(0);
            clan.addClanMember(player);
            player.broadcastUserInfo();
         }
      }

   }

   private void createFantomAlly(L2Clan clanFantom) {
      clanFantom.setAllyId(clanFantom.getClanId());
      clanFantom.setAllyName(this.getRndAllyName());
   }
}
