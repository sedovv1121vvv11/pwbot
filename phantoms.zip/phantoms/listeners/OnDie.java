package phantoms.listeners;

import net.sf.l2j.gameserver.model.L2Character;
import net.sf.l2j.gameserver.model.actor.player.OnDeathListener;

public class OnDie implements OnDeathListener {
   public void onDeath(L2Character attacker, L2Character target) {
      if (target.isPlayer()) {
         target.getPlayer().isPhantoms();
      }

   }
}
