package phantoms.listeners;

import net.sf.l2j.gameserver.model.L2Character;
import net.sf.l2j.gameserver.model.actor.player.OnAttackListener;

public class OnAttack implements OnAttackListener {
   public void onAttack(L2Character attacker, L2Character target) {
   }
}
