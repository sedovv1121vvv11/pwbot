package phantoms.listeners;

import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.player.OnPlayerExitListener;
import phantoms.FantomsManager;

public class PlayerExit implements OnPlayerExitListener {
   public void onPlayerExit(L2PcInstance player) {
      FantomsManager.getInstance().endLogging(player.getObjectId());
   }
}
