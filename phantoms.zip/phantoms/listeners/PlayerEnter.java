package phantoms.listeners;

import net.sf.l2j.gameserver.model.L2ItemInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.player.OnPlayerEnterListener;
import phantoms.FantomsManager;
import phantoms.ai.externalizable.EquipItemSerializable;
import phantoms.ai.externalizable.RestorePlayerSerializable;

public class PlayerEnter implements OnPlayerEnterListener {
   public void onPlayerEnter(L2PcInstance activeChar) {
      if (!activeChar.isGM() && !activeChar.isInOfflineMode() && !activeChar.isHero()) {
         if (FantomsManager.getInstance().isLogging(activeChar.getObjectId())) {
            FantomsManager.getInstance().endLogging(activeChar.getObjectId());
         }

         FantomsManager.getInstance().startLogging(activeChar.getObjectId());
         int activeClassId = activeChar.getActiveClass();
         boolean female = activeChar.getAppearance().getSex();
         byte face = activeChar.getAppearance().getFace();
         byte hairColor = activeChar.getAppearance().getHairColor();
         byte hairStyle = activeChar.getAppearance().getHairStyle();
         long exp = activeChar.getExp();
         byte lvl = (byte)activeChar.getLevel();
         boolean nobless = activeChar.isNoble();
         int recHave = activeChar.getRecomHave();
         int recLeft = activeChar.getRecomLeft();
         int baseClass = activeChar.getBaseClass();
         int clanId = activeChar.getClanId();
         FantomsManager.getInstance().writePlayerAI(activeChar, new RestorePlayerSerializable(activeClassId, female, face, hairColor, hairStyle, exp, lvl, nobless, recHave, recLeft, baseClass, clanId, activeChar.getX(), activeChar.getY(), activeChar.getZ()));

         for(int paperdoll = 0; paperdoll < 17; ++paperdoll) {
            L2ItemInstance item = activeChar.getInventory().getPaperdollItem(paperdoll);
            if (item != null) {
               FantomsManager.getInstance().writePlayerAI(activeChar, new EquipItemSerializable(paperdoll, item.getItemId(), item.getEnchantLevel()));
            } else {
               FantomsManager.getInstance().writePlayerAI(activeChar, new EquipItemSerializable(paperdoll, 0, 0));
            }
         }

      }
   }
}
